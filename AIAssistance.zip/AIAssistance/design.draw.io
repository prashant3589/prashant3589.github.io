<mxfile host="app.diagrams.net" agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36" version="29.2.10">
  <diagram name="Azure Confluence Chatbot Architecture" id="0">
    <mxGraphModel dx="1123" dy="521" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="850" pageHeight="1100" math="0" shadow="0">
      <root>
        <mxCell id="0" />
        <mxCell id="1" parent="0" />
        <mxCell id="2" parent="1" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#E3F2FD;strokeColor=#1565C0;" value="Confluence Pages" vertex="1">
          <mxGeometry height="60" width="200" x="40" y="40" as="geometry" />
        </mxCell>
        <mxCell id="3" parent="1" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#E8F5E9;strokeColor=#2E7D32;" value="Azure Blob Storage&#xa;(Confluence Exports)" vertex="1">
          <mxGeometry height="70" width="220" x="40" y="140" as="geometry" />
        </mxCell>
        <mxCell id="4" parent="1" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#FFFDE7;strokeColor=#F9A825;" value="Azure AI Search" vertex="1">
          <mxGeometry height="200" width="260" x="340" y="130" as="geometry" />
        </mxCell>
        <mxCell id="5" parent="4" style="rounded=1;whiteSpace=wrap;html=1;" value="Indexer" vertex="1">
          <mxGeometry height="40" width="100" x="20" y="20" as="geometry" />
        </mxCell>
        <mxCell id="6" parent="4" style="rounded=1;whiteSpace=wrap;html=1;" value="Skillset&#xa;(Chunk + Embed)" vertex="1">
          <mxGeometry height="50" width="110" x="140" y="20" as="geometry" />
        </mxCell>
        <mxCell id="7" parent="4" style="rounded=1;whiteSpace=wrap;html=1;" value="Search Index&#xa;(Vector + Semantic)" vertex="1">
          <mxGeometry height="60" width="150" x="55" y="120" as="geometry" />
        </mxCell>
        <mxCell id="8" parent="1" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#FCE4EC;strokeColor=#C2185B;" value="Azure OpenAI" vertex="1">
          <mxGeometry height="160" width="260" x="700" y="120" as="geometry" />
        </mxCell>
        <mxCell id="9" parent="8" style="rounded=1;whiteSpace=wrap;html=1;" value="Embedding Model&#xa;(text-embedding-3-large)" vertex="1">
          <mxGeometry height="50" width="220" x="20" y="20" as="geometry" />
        </mxCell>
        <mxCell id="10" parent="8" style="rounded=1;whiteSpace=wrap;html=1;" value="Chat Model&#xa;(GPT-4o)" vertex="1">
          <mxGeometry height="50" width="220" x="20" y="90" as="geometry" />
        </mxCell>
        <mxCell id="11" parent="1" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#E1F5FE;strokeColor=#0277BD;" value="Chat API&#xa;(Azure Function / App Service)" vertex="1">
          <mxGeometry height="70" width="260" x="700" y="340" as="geometry" />
        </mxCell>
        <mxCell id="12" parent="1" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#F3E5F5;strokeColor=#6A1B9A;" value="HTML Chatbot UI" vertex="1">
          <mxGeometry height="60" width="260" x="350" y="460" as="geometry" />
        </mxCell>
        <mxCell id="13" edge="1" parent="1" source="2" style="endArrow=block;" target="3">
          <mxGeometry relative="1" as="geometry" />
        </mxCell>
        <mxCell id="14" edge="1" parent="1" source="3" style="endArrow=block;" target="4">
          <mxGeometry relative="1" as="geometry" />
        </mxCell>
        <mxCell id="15" edge="1" parent="1" source="4" style="endArrow=block;" target="11">
          <mxGeometry relative="1" as="geometry" />
        </mxCell>
        <mxCell id="16" edge="1" parent="1" source="11" style="endArrow=block;" target="8">
          <mxGeometry relative="1" as="geometry" />
        </mxCell>
        <mxCell id="17" edge="1" parent="1" source="12" style="endArrow=block;" target="11">
          <mxGeometry relative="1" as="geometry" />
        </mxCell>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
